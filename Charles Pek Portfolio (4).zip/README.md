
  # Charles Pek Portfolio

  This is a code bundle for Charles Pek Portfolio. The original project is available at https://www.figma.com/design/AHUZG1jS1uLVFGUGJ4Y6m7/Charles-Pek-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  